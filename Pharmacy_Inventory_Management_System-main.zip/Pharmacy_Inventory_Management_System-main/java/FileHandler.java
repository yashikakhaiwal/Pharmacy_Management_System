package com.healthcare.util;

import java.io.FileWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import com.healthcare.model.Medicine;

public class FileHandler {

    public static void save(List<Medicine> items) throws Exception 
    {

        FileWriter fw = new FileWriter("receipt.txt", true);

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

        fw.write("=================================\n");
        fw.write("HEALTHCARE PHARMACY\n");
        fw.write("Date: " + dtf.format(LocalDateTime.now()) + "\n");
        fw.write("---------------------------------\n");

        Map<String, Integer> map = new LinkedHashMap<>();
        Map<String, Double> price = new HashMap<>();

        for (Medicine m : items) {
            map.put(m.getName(), map.getOrDefault(m.getName(), 0) + 1);
            price.put(m.getName(), m.getPrice());
        }

        double total = 0;

        for (String name : map.keySet()) {
            int qty = map.get(name);
            double p = price.get(name);
            double t = qty * p;
            total += t;

            fw.write(name + " x" + qty + " = " + t + "\n");
        }

        fw.write("---------------------------------\n");
        fw.write("Total: " + total + "\n");
        fw.write("=================================\n\n");

        fw.close();
        
    }
    public static String readAll() throws Exception {
        java.nio.file.Path path = java.nio.file.Paths.get("receipt.txt");

        if (!java.nio.file.Files.exists(path))
            return "No receipts found.";

        return new String(java.nio.file.Files.readAllBytes(path));
    }
}