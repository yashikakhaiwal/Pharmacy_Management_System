package com.healthcare.ui;

import javax.swing.*;
import java.awt.*;
import com.healthcare.util.FileHandler;

public class ReceiptPanel extends JPanel {

    JTextArea area;

    public ReceiptPanel() {

        setLayout(new BorderLayout(10,10));
        setBorder(BorderFactory.createEmptyBorder(15,15,15,15));

        area = new JTextArea();
        area.setEditable(false);
        area.setFont(new Font("Monospaced", Font.PLAIN, 14));

        JScrollPane scroll = new JScrollPane(area);

        JButton refresh = new JButton("Refresh");

        add(scroll, BorderLayout.CENTER);
        add(refresh, BorderLayout.SOUTH);

        refresh.addActionListener(e -> loadReceipts());

        loadReceipts();
    }

    public void loadReceipts() {
        try {
            area.setText(FileHandler.readAll());
        } catch (Exception e) {
            area.setText(e.getMessage());
        }
    }
}