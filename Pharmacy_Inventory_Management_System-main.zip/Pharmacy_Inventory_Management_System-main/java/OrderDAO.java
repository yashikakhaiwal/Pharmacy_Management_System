package com.healthcare.dao;

import java.sql.*;
import java.util.*;
import com.healthcare.model.Medicine;

public class OrderDAO {

    public void save(List<Medicine> items) throws Exception {

        Connection con = DBConnection.getConnection();
        con.setAutoCommit(false);

        double total = 0;
        for (Medicine m : items) total += m.getPrice();

        PreparedStatement ps = con.prepareStatement(
            "INSERT INTO orders(total) VALUES(?)",
            Statement.RETURN_GENERATED_KEYS
        );
        ps.setDouble(1, total);
        ps.executeUpdate();

        ResultSet rs = ps.getGeneratedKeys();
        rs.next();
        int orderId = rs.getInt(1);

        PreparedStatement itemStmt = con.prepareStatement(
            "INSERT INTO order_items(order_id, medicine_id, qty, price) VALUES (?, ?, ?, ?)"
        );

        Map<Integer, Integer> map = new HashMap<>();
        for (Medicine m : items)
            map.put(m.getId(), map.getOrDefault(m.getId(), 0) + 1);

        for (int id : map.keySet()) {
            itemStmt.setInt(1, orderId);
            itemStmt.setInt(2, id);
            itemStmt.setInt(3, map.get(id));
            itemStmt.setDouble(4, 0);
            itemStmt.addBatch();
        }

        itemStmt.executeBatch();
        con.commit();
        con.close();
    }
}
