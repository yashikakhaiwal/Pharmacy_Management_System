package com.healthcare.ui;

import javax.swing.*;
import java.awt.*;

public class DashboardFrame extends JFrame {

    CardLayout layout = new CardLayout();
    JPanel content = new JPanel(layout);

    public DashboardFrame() {

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        setTitle("Pharmacy Management System");
        setSize(1000, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        InventoryPanel inventoryPanel = new InventoryPanel();
        ReceiptPanel receiptPanel = new ReceiptPanel();
        BillingPanel billingPanel = new BillingPanel(inventoryPanel, receiptPanel);

        JPanel sidebar = new JPanel(new GridLayout(6,1,10,10));
        sidebar.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        JButton invBtn = new JButton("Inventory");
        JButton billBtn = new JButton("Billing");
        JButton recBtn = new JButton("Receipts");

        sidebar.add(invBtn);
        sidebar.add(billBtn);
        sidebar.add(recBtn);

        content.add(inventoryPanel, "inv");
        content.add(billingPanel, "bill");
        content.add(receiptPanel, "rec");

        add(sidebar, BorderLayout.WEST);
        add(content, BorderLayout.CENTER);

        invBtn.addActionListener(e -> layout.show(content, "inv"));

        billBtn.addActionListener(e -> {
            billingPanel.loadInventory();   // auto refresh billing
            layout.show(content, "bill");
        });

        recBtn.addActionListener(e -> {
            receiptPanel.loadReceipts();    // auto refresh receipts
            layout.show(content, "rec");
        });
    }
}