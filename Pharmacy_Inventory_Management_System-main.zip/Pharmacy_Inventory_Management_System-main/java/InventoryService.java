package com.healthcare.service;

import java.util.*;
import com.healthcare.dao.MedicineDAO;
import com.healthcare.model.Medicine;

public class InventoryService {

    private MedicineDAO dao = new MedicineDAO();

    public void addMedicine(Medicine m) throws Exception {
        if (dao.find(m.getId()) != null)
            throw new Exception("Already exists");
        dao.add(m);
    }

    public List<Medicine> getAll() throws Exception {
        return dao.getAll();
    }

    public Medicine find(int id) throws Exception {
        return dao.find(id);
    }

    public void reduceStock(int id, int qty) throws Exception {
        dao.updateStock(id, qty);
    }
}