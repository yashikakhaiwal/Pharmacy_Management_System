package com.healthcare.service;

import java.util.*;
import com.healthcare.model.*;
import com.healthcare.dao.*;
import com.healthcare.util.*;

public class BillingService {

    private Map<Medicine, Integer> cart = new LinkedHashMap<>();
    private OrderDAO dao = new OrderDAO();
    private MedicineDAO medDAO = new MedicineDAO();

    public void addToCart(Medicine m, int qty) {
        cart.put(m, cart.getOrDefault(m, 0) + qty);
    }

    public void removeFromCart(Medicine m) {
        if (cart.containsKey(m)) {
            int q = cart.get(m);
            if (q == 1) cart.remove(m);
            else cart.put(m, q - 1);
        }
    }

    public Map<Medicine, Integer> getCart() {
        return cart;
    }

    public double total() {
        double total = 0;
        for (Medicine m : cart.keySet()) {
            total += m.getPrice() * cart.get(m);
        }
        return total;
    }

    public void purchase() throws Exception {

        if (cart.isEmpty())
            throw new Exception("Cart empty");

        List<Medicine> list = new ArrayList<>();

        for (Medicine m : cart.keySet()) {

            int qty = cart.get(m);

            if (qty > m.getQuantity())
                throw new Exception("Insufficient stock for " + m.getName());

            medDAO.updateStock(m.getId(), qty);

            for (int i = 0; i < qty; i++)
                list.add(m);
        }

        dao.save(list);
        FileHandler.save(list);

        cart.clear();
    }
}