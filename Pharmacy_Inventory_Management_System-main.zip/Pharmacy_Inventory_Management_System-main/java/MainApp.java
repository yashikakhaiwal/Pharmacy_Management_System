package com.healthcare.main;

import javax.swing.SwingUtilities;
import com.healthcare.ui.DashboardFrame;

public class MainApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new DashboardFrame().setVisible(true);
        });
    }
}