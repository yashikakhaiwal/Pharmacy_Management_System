package com.healthcare.ui;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;
import com.healthcare.model.*;
import com.healthcare.service.*;

public class InventoryPanel extends JPanel {

    JTextField id, name, price, qty, search;
    DefaultTableModel model;
    JTable table;

    InventoryService service = new InventoryService();

    public InventoryPanel() {

        setLayout(new BorderLayout(10,10));
        setBorder(BorderFactory.createEmptyBorder(15,15,15,15));

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5,5,5,5);

        id = new JTextField(8);
        name = new JTextField(10);
        price = new JTextField(8);
        qty = new JTextField(8);

        JButton addBtn = new JButton("Add");
        JButton clearBtn = new JButton("Clear");

        styleButton(addBtn);
        styleButton(clearBtn);

        g.gridx=0; g.gridy=0; form.add(new JLabel("ID"), g);
        g.gridx=1; form.add(id, g);
        g.gridx=2; form.add(new JLabel("Name"), g);
        g.gridx=3; form.add(name, g);

        g.gridx=0; g.gridy=1; form.add(new JLabel("Price"), g);
        g.gridx=1; form.add(price, g);
        g.gridx=2; form.add(new JLabel("Qty"), g);
        g.gridx=3; form.add(qty, g);

        g.gridx=4; g.gridy=0; form.add(addBtn, g);
        g.gridx=4; g.gridy=1; form.add(clearBtn, g);

        add(form, BorderLayout.NORTH);

        model = new DefaultTableModel(new String[]{"ID","Name","Price","Stock"},0);
        table = new JTable(model);
        table.setRowHeight(25);
        table.setAutoCreateRowSorter(true);
        table.setGridColor(Color.LIGHT_GRAY);

        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel bottom = new JPanel(new BorderLayout());
        search = new JTextField();
        bottom.add(new JLabel("Search: "), BorderLayout.WEST);
        bottom.add(search, BorderLayout.CENTER);

        add(bottom, BorderLayout.SOUTH);

        addBtn.addActionListener(e -> addMedicine());
        clearBtn.addActionListener(e -> clearFields());
        search.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent e) {
                filter();
            }
        });

        loadData();
    }

    void addMedicine() {
        try {
            if (id.getText().isEmpty()) throw new Exception("Enter ID");

            service.addMedicine(new Medicine(
                    Integer.parseInt(id.getText()),
                    name.getText(),
                    Double.parseDouble(price.getText()),
                    Integer.parseInt(qty.getText())
            ));

            loadData();
            clearFields();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    void loadData() {
        try {
            model.setRowCount(0);
            List<Medicine> list = service.getAll();
            for (Medicine m : list) {
                model.addRow(new Object[]{
                        m.getId(),
                        m.getName(),
                        m.getPrice(),
                        m.getQuantity()
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    void clearFields() {
        id.setText(""); name.setText("");
        price.setText(""); qty.setText("");
    }

    void filter() {
        TableRowSorter<DefaultTableModel> sorter =
                (TableRowSorter<DefaultTableModel>) table.getRowSorter();
        sorter.setRowFilter(RowFilter.regexFilter(search.getText()));
    }

    void styleButton(JButton btn) {
        btn.setFocusPainted(false);
        btn.setPreferredSize(new Dimension(100, 35));
    }
}