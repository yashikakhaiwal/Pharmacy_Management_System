package com.healthcare.dao;

import java.sql.*;
import java.util.*;
import com.healthcare.model.Medicine;

public class MedicineDAO {

    public void add(Medicine m) throws Exception {
        Connection con = DBConnection.getConnection();
        PreparedStatement ps = con.prepareStatement(
            "INSERT INTO medicine VALUES (?, ?, ?, ?)"
        );
        ps.setInt(1, m.getId());
        ps.setString(2, m.getName());
        ps.setDouble(3, m.getPrice());
        ps.setInt(4, m.getQuantity());
        ps.executeUpdate();
        con.close();
    }

    public List<Medicine> getAll() throws Exception {
        List<Medicine> list = new ArrayList<>();
        Connection con = DBConnection.getConnection();
        ResultSet rs = con.createStatement().executeQuery("SELECT * FROM medicine");

        while (rs.next()) {
            list.add(new Medicine(
                rs.getInt(1),
                rs.getString(2),
                rs.getDouble(3),
                rs.getInt(4)
            ));
        }
        con.close();
        return list;
    }

    public Medicine find(int id) throws Exception {
        Connection con = DBConnection.getConnection();
        PreparedStatement ps = con.prepareStatement("SELECT * FROM medicine WHERE id=?");
        ps.setInt(1, id);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            return new Medicine(
                rs.getInt(1),
                rs.getString(2),
                rs.getDouble(3),
                rs.getInt(4)
            );
        }
        return null;
    }

    public void updateStock(int id, int qty) throws Exception {
        Connection con = DBConnection.getConnection();
        PreparedStatement ps = con.prepareStatement(
            "UPDATE medicine SET quantity = quantity - ? WHERE id=?"
        );
        ps.setInt(1, qty);
        ps.setInt(2, id);
        ps.executeUpdate();
        con.close();
    }
}