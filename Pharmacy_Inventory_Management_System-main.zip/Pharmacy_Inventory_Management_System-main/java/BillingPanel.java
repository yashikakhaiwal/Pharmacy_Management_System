package com.healthcare.ui;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.*;
import com.healthcare.model.*;
import com.healthcare.service.*;

public class BillingPanel extends JPanel {

    InventoryService inv = new InventoryService();
    BillingService bill = new BillingService();

    InventoryPanel inventoryPanel;
    ReceiptPanel receiptPanel;

    DefaultTableModel model;
    JTable table;
    JLabel totalLabel;

    java.util.List<Medicine> inventoryList = new ArrayList<>();

    public BillingPanel(InventoryPanel inventoryPanel, ReceiptPanel receiptPanel) {

        this.inventoryPanel = inventoryPanel;
        this.receiptPanel = receiptPanel;

        setLayout(new BorderLayout(10,10));
        setBorder(BorderFactory.createEmptyBorder(15,15,15,15));

        model = new DefaultTableModel(
                new String[]{"Name","Price","Qty","Subtotal","+","-"}, 0) {
            public boolean isCellEditable(int r, int c) {
                return c >= 4;
            }
        };

        table = new JTable(model);
        table.setRowHeight(30);

        table.getColumn("+").setCellRenderer(new ButtonRenderer("+"));
        table.getColumn("+").setCellEditor(new ButtonEditor("+"));

        table.getColumn("-").setCellRenderer(new ButtonRenderer("-"));
        table.getColumn("-").setCellEditor(new ButtonEditor("-"));

        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel bottom = new JPanel(new BorderLayout());

        totalLabel = new JLabel("Total: Rs. 0.00");
        totalLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));

        JButton purchaseBtn = new JButton("Purchase");
        purchaseBtn.addActionListener(e -> purchase());

        bottom.add(totalLabel, BorderLayout.WEST);
        bottom.add(purchaseBtn, BorderLayout.EAST);

        add(bottom, BorderLayout.SOUTH);

        loadInventory();
    }

    void loadInventory() {
        try {
            model.setRowCount(0);
            inventoryList = inv.getAll();

            for (Medicine m : inventoryList) {
                model.addRow(new Object[]{
                        m.getName(),
                        m.getPrice(),
                        0,
                        0.0,
                        "+",
                        "-"
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    void addItem(int row) {
        Medicine m = inventoryList.get(row);

        bill.addToCart(m, 1);

        int qty = (int) model.getValueAt(row, 2) + 1;
        double subtotal = qty * m.getPrice();

        model.setValueAt(qty, row, 2);
        model.setValueAt(subtotal, row, 3);

        updateTotal();
    }

    void removeItem(int row) {
        Medicine m = inventoryList.get(row);

        int qty = (int) model.getValueAt(row, 2);

        if (qty > 0) {
            bill.removeFromCart(m);

            qty--;
            double subtotal = qty * m.getPrice();

            model.setValueAt(qty, row, 2);
            model.setValueAt(subtotal, row, 3);

            updateTotal();
        }
    }

    void updateTotal() {
        totalLabel.setText("Total: Rs. " + bill.total());
    }

    void purchase() {
        try {

            int confirm = JOptionPane.showConfirmDialog(this,
                    "Confirm purchase?", "Confirm", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {

                bill.purchase();

                loadInventory();
                inventoryPanel.loadData();
                receiptPanel.loadReceipts();   // 🔥 LIVE RECEIPT UPDATE
                updateTotal();

                JOptionPane.showMessageDialog(this, "Purchase Complete");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer(String text) { setText(text); }
        public Component getTableCellRendererComponent(
                JTable table, Object value, boolean isSelected,
                boolean hasFocus, int row, int column) {
            return this;
        }
    }

    class ButtonEditor extends DefaultCellEditor {

        JButton button;
        String label;

        public ButtonEditor(String text) {
            super(new JTextField());
            button = new JButton(text);
            label = text;

            button.addActionListener(e -> {
                int row = table.getSelectedRow();
                if (label.equals("+"))
                    addItem(row);
                else
                    removeItem(row);
            });
        }

        public Component getTableCellEditorComponent(
                JTable table, Object value, boolean isSelected,
                int row, int column) {
            return button;
        }
    }
}